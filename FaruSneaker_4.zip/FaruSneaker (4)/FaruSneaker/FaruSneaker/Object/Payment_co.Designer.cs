﻿namespace FaruSneaker.Object
{
    partial class Payment_co
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rtx_TotalCash = new System.Windows.Forms.TextBox();
            this.rtx_IntoCash = new System.Windows.Forms.TextBox();
            this.rtx_Discount = new System.Windows.Forms.TextBox();
            this.rtx_Price = new System.Windows.Forms.TextBox();
            this.rtx_PName = new System.Windows.Forms.TextBox();
            this.rtx_PID = new System.Windows.Forms.TextBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_CancelBill = new System.Windows.Forms.Button();
            this.btn_PayBill = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.dgv_Payment = new System.Windows.Forms.DataGridView();
            this.nbr_Num = new System.Windows.Forms.NumericUpDown();
            this.btn_AddBill = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rtx_StaffName = new System.Windows.Forms.TextBox();
            this.rtx_CusName = new System.Windows.Forms.TextBox();
            this.rtx_BillID = new System.Windows.Forms.TextBox();
            this.cbx_StaffID = new System.Windows.Forms.ComboBox();
            this.cbx_CusID = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.cButton7 = new FaruSneaker.CButton();
            this.rjTextBox1 = new CustomControls.RJControls.RJTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Payment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbr_Num)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImage = global::FaruSneaker.Properties.Resources._while;
            this.groupBox2.Controls.Add(this.rtx_TotalCash);
            this.groupBox2.Controls.Add(this.rtx_IntoCash);
            this.groupBox2.Controls.Add(this.rtx_Discount);
            this.groupBox2.Controls.Add(this.rtx_Price);
            this.groupBox2.Controls.Add(this.rtx_PName);
            this.groupBox2.Controls.Add(this.rtx_PID);
            this.groupBox2.Controls.Add(this.btn_Add);
            this.groupBox2.Controls.Add(this.btn_CancelBill);
            this.groupBox2.Controls.Add(this.btn_PayBill);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.dgv_Payment);
            this.groupBox2.Controls.Add(this.nbr_Num);
            this.groupBox2.Controls.Add(this.btn_AddBill);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(31, 242);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1133, 446);
            this.groupBox2.TabIndex = 92;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin các mặt hàng";
            // 
            // rtx_TotalCash
            // 
            this.rtx_TotalCash.Location = new System.Drawing.Point(885, 408);
            this.rtx_TotalCash.Name = "rtx_TotalCash";
            this.rtx_TotalCash.Size = new System.Drawing.Size(234, 32);
            this.rtx_TotalCash.TabIndex = 108;
            // 
            // rtx_IntoCash
            // 
            this.rtx_IntoCash.Location = new System.Drawing.Point(885, 76);
            this.rtx_IntoCash.Name = "rtx_IntoCash";
            this.rtx_IntoCash.Size = new System.Drawing.Size(234, 32);
            this.rtx_IntoCash.TabIndex = 107;
            // 
            // rtx_Discount
            // 
            this.rtx_Discount.Location = new System.Drawing.Point(885, 42);
            this.rtx_Discount.Name = "rtx_Discount";
            this.rtx_Discount.Size = new System.Drawing.Size(234, 32);
            this.rtx_Discount.TabIndex = 106;
            // 
            // rtx_Price
            // 
            this.rtx_Price.Location = new System.Drawing.Point(524, 39);
            this.rtx_Price.Name = "rtx_Price";
            this.rtx_Price.Size = new System.Drawing.Size(234, 32);
            this.rtx_Price.TabIndex = 105;
            // 
            // rtx_PName
            // 
            this.rtx_PName.Location = new System.Drawing.Point(145, 75);
            this.rtx_PName.Name = "rtx_PName";
            this.rtx_PName.Size = new System.Drawing.Size(234, 32);
            this.rtx_PName.TabIndex = 104;
            // 
            // rtx_PID
            // 
            this.rtx_PID.Location = new System.Drawing.Point(145, 39);
            this.rtx_PID.Name = "rtx_PID";
            this.rtx_PID.Size = new System.Drawing.Size(234, 32);
            this.rtx_PID.TabIndex = 103;
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.btn_Add.ForeColor = System.Drawing.Color.Black;
            this.btn_Add.Location = new System.Drawing.Point(185, 116);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(194, 37);
            this.btn_Add.TabIndex = 99;
            this.btn_Add.Text = "Thêm hóa đơn";
            this.btn_Add.UseVisualStyleBackColor = false;
            // 
            // btn_CancelBill
            // 
            this.btn_CancelBill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.btn_CancelBill.ForeColor = System.Drawing.Color.Black;
            this.btn_CancelBill.Location = new System.Drawing.Point(288, 403);
            this.btn_CancelBill.Name = "btn_CancelBill";
            this.btn_CancelBill.Size = new System.Drawing.Size(194, 37);
            this.btn_CancelBill.TabIndex = 97;
            this.btn_CancelBill.Text = "Hủy hóa đơn";
            this.btn_CancelBill.UseVisualStyleBackColor = false;
            // 
            // btn_PayBill
            // 
            this.btn_PayBill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.btn_PayBill.ForeColor = System.Drawing.Color.Black;
            this.btn_PayBill.Location = new System.Drawing.Point(564, 403);
            this.btn_PayBill.Name = "btn_PayBill";
            this.btn_PayBill.Size = new System.Drawing.Size(194, 37);
            this.btn_PayBill.TabIndex = 96;
            this.btn_PayBill.Text = "Thanh toán";
            this.btn_PayBill.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(810, 416);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 24);
            this.label5.TabIndex = 94;
            this.label5.Text = "Tổng tiền";
            // 
            // dgv_Payment
            // 
            this.dgv_Payment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Payment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Payment.Location = new System.Drawing.Point(19, 159);
            this.dgv_Payment.Name = "dgv_Payment";
            this.dgv_Payment.RowHeadersWidth = 51;
            this.dgv_Payment.RowTemplate.Height = 29;
            this.dgv_Payment.Size = new System.Drawing.Size(1105, 238);
            this.dgv_Payment.TabIndex = 90;
            // 
            // nbr_Num
            // 
            this.nbr_Num.Location = new System.Drawing.Point(525, 76);
            this.nbr_Num.Name = "nbr_Num";
            this.nbr_Num.Size = new System.Drawing.Size(233, 32);
            this.nbr_Num.TabIndex = 88;
            // 
            // btn_AddBill
            // 
            this.btn_AddBill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.btn_AddBill.ForeColor = System.Drawing.Color.Black;
            this.btn_AddBill.Location = new System.Drawing.Point(14, 403);
            this.btn_AddBill.Name = "btn_AddBill";
            this.btn_AddBill.Size = new System.Drawing.Size(194, 37);
            this.btn_AddBill.TabIndex = 82;
            this.btn_AddBill.Text = "Thêm hóa đơn";
            this.btn_AddBill.UseVisualStyleBackColor = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(782, 47);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 24);
            this.label12.TabIndex = 84;
            this.label12.Text = "Chiết khấu";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(782, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 24);
            this.label13.TabIndex = 85;
            this.label13.Text = "Thành tiền";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(14, 50);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 24);
            this.label15.TabIndex = 69;
            this.label15.Text = "Mã sản phẩm";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(395, 47);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 24);
            this.label16.TabIndex = 71;
            this.label16.Text = "Đơn giá";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(395, 84);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 24);
            this.label17.TabIndex = 74;
            this.label17.Text = "Số lượng";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(14, 84);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 24);
            this.label18.TabIndex = 78;
            this.label18.Text = "Tên sản phẩm";
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = global::FaruSneaker.Properties.Resources._while;
            this.groupBox1.Controls.Add(this.rtx_StaffName);
            this.groupBox1.Controls.Add(this.rtx_CusName);
            this.groupBox1.Controls.Add(this.rtx_BillID);
            this.groupBox1.Controls.Add(this.cbx_StaffID);
            this.groupBox1.Controls.Add(this.cbx_CusID);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.dtp_Date);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(31, 104);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1133, 121);
            this.groupBox1.TabIndex = 91;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin thanh toán";
            // 
            // rtx_StaffName
            // 
            this.rtx_StaffName.Location = new System.Drawing.Point(885, 76);
            this.rtx_StaffName.Name = "rtx_StaffName";
            this.rtx_StaffName.Size = new System.Drawing.Size(234, 32);
            this.rtx_StaffName.TabIndex = 102;
            // 
            // rtx_CusName
            // 
            this.rtx_CusName.Location = new System.Drawing.Point(524, 77);
            this.rtx_CusName.Name = "rtx_CusName";
            this.rtx_CusName.Size = new System.Drawing.Size(234, 32);
            this.rtx_CusName.TabIndex = 101;
            // 
            // rtx_BillID
            // 
            this.rtx_BillID.Location = new System.Drawing.Point(145, 36);
            this.rtx_BillID.Name = "rtx_BillID";
            this.rtx_BillID.Size = new System.Drawing.Size(234, 32);
            this.rtx_BillID.TabIndex = 89;
            // 
            // cbx_StaffID
            // 
            this.cbx_StaffID.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbx_StaffID.FormattingEnabled = true;
            this.cbx_StaffID.Location = new System.Drawing.Point(885, 38);
            this.cbx_StaffID.Name = "cbx_StaffID";
            this.cbx_StaffID.Size = new System.Drawing.Size(234, 30);
            this.cbx_StaffID.TabIndex = 100;
            // 
            // cbx_CusID
            // 
            this.cbx_CusID.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cbx_CusID.FormattingEnabled = true;
            this.cbx_CusID.Location = new System.Drawing.Point(524, 38);
            this.cbx_CusID.Name = "cbx_CusID";
            this.cbx_CusID.Size = new System.Drawing.Size(234, 30);
            this.cbx_CusID.TabIndex = 99;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(782, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 24);
            this.label10.TabIndex = 84;
            this.label10.Text = "Mã nhân viên";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(782, 84);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 24);
            this.label11.TabIndex = 85;
            this.label11.Text = "Tên nhân viên";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dtp_Date.Location = new System.Drawing.Point(145, 76);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(234, 32);
            this.dtp_Date.TabIndex = 75;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(14, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 24);
            this.label2.TabIndex = 69;
            this.label2.Text = "Mã hóa đơn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(395, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 24);
            this.label3.TabIndex = 71;
            this.label3.Text = "Mã khách hàng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(395, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 24);
            this.label4.TabIndex = 74;
            this.label4.Text = "Tên khách hàng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(14, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 24);
            this.label7.TabIndex = 78;
            this.label7.Text = "Ngày lập hóa đơn";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(504, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(157, 28);
            this.label9.TabIndex = 90;
            this.label9.Text = "HÓA ĐƠN BÁN HÀNG";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label1);
            this.panel8.Controls.Add(this.cButton7);
            this.panel8.Controls.Add(this.rjTextBox1);
            this.panel8.Controls.Add(this.pictureBox1);
            this.panel8.Location = new System.Drawing.Point(1, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1175, 78);
            this.panel8.TabIndex = 89;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1053, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Đăng xuất";
            // 
            // cButton7
            // 
            this.cButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.cButton7.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.cButton7.BorderColor = System.Drawing.Color.Transparent;
            this.cButton7.BorderRadius = 1;
            this.cButton7.BorderSize = 0;
            this.cButton7.FlatAppearance.BorderSize = 0;
            this.cButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton7.ForeColor = System.Drawing.Color.Transparent;
            this.cButton7.Image = global::FaruSneaker.Properties.Resources.search;
            this.cButton7.Location = new System.Drawing.Point(567, 20);
            this.cButton7.Name = "cButton7";
            this.cButton7.Size = new System.Drawing.Size(81, 39);
            this.cButton7.TabIndex = 1;
            this.cButton7.TextColor = System.Drawing.Color.Transparent;
            this.cButton7.UseVisualStyleBackColor = false;
            // 
            // rjTextBox1
            // 
            this.rjTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.rjTextBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.rjTextBox1.BorderColor = System.Drawing.Color.Transparent;
            this.rjTextBox1.BorderFocusColor = System.Drawing.Color.Transparent;
            this.rjTextBox1.BorderSize = 1;
            this.rjTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.rjTextBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rjTextBox1.ForeColor = System.Drawing.Color.Black;
            this.rjTextBox1.Location = new System.Drawing.Point(21, 20);
            this.rjTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.rjTextBox1.Multiline = true;
            this.rjTextBox1.Name = "rjTextBox1";
            this.rjTextBox1.Padding = new System.Windows.Forms.Padding(7);
            this.rjTextBox1.PasswordChar = false;
            this.rjTextBox1.Size = new System.Drawing.Size(627, 39);
            this.rjTextBox1.TabIndex = 1;
            this.rjTextBox1.Texts = "";
            this.rjTextBox1.UnderlinedStyle = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1178, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Payment_co
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel8);
            this.Name = "Payment_co";
            this.Size = new System.Drawing.Size(1180, 729);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Payment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbr_Num)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox groupBox2;
        private TextBox rtx_TotalCash;
        private TextBox rtx_IntoCash;
        private TextBox rtx_Discount;
        private TextBox rtx_Price;
        private TextBox rtx_PName;
        private TextBox rtx_PID;
        private Button btn_Add;
        private Button btn_CancelBill;
        private Button btn_PayBill;
        private Label label5;
        private DataGridView dgv_Payment;
        private NumericUpDown nbr_Num;
        private Button btn_AddBill;
        private Label label12;
        private Label label13;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private GroupBox groupBox1;
        private TextBox rtx_StaffName;
        private TextBox rtx_CusName;
        private TextBox rtx_BillID;
        private ComboBox cbx_StaffID;
        private ComboBox cbx_CusID;
        private Label label10;
        private Label label11;
        private DateTimePicker dtp_Date;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label7;
        private Label label9;
        private Panel panel8;
        private Label label1;
        private CButton cButton7;
        private CustomControls.RJControls.RJTextBox rjTextBox1;
        private PictureBox pictureBox1;
    }
}
