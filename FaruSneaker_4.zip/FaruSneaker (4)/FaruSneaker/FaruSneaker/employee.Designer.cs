﻿namespace FaruSneaker
{
    partial class employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel6 = new System.Windows.Forms.Panel();
            this.cButton6 = new FaruSneaker.CButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cButton5 = new FaruSneaker.CButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cButton4 = new FaruSneaker.CButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cButton3 = new FaruSneaker.CButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cButton2 = new FaruSneaker.CButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cButton1 = new FaruSneaker.CButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_ci = new System.Windows.Forms.TextBox();
            this.txt_add = new System.Windows.Forms.TextBox();
            this.txt_ephone = new System.Windows.Forms.TextBox();
            this.txt_ename = new System.Windows.Forms.TextBox();
            this.txt_eid = new System.Windows.Forms.TextBox();
            this.txt_salary = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.table_E = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dob = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_search = new FaruSneaker.CButton();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.error = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table_E)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.error)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(194)))), ((int)(((byte)(57)))));
            this.splitContainer1.Panel1.Controls.Add(this.panel6);
            this.splitContainer1.Panel1.Controls.Add(this.panel5);
            this.splitContainer1.Panel1.Controls.Add(this.panel4);
            this.splitContainer1.Panel1.Controls.Add(this.panel3);
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel2.Controls.Add(this.panel8);
            this.splitContainer1.Size = new System.Drawing.Size(1376, 703);
            this.splitContainer1.SplitterDistance = 193;
            this.splitContainer1.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.Controls.Add(this.cButton6);
            this.panel6.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel6.Location = new System.Drawing.Point(4, 475);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(186, 58);
            this.panel6.TabIndex = 8;
            // 
            // cButton6
            // 
            this.cButton6.BackColor = System.Drawing.Color.Transparent;
            this.cButton6.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton6.BorderColor = System.Drawing.Color.Transparent;
            this.cButton6.BorderRadius = 0;
            this.cButton6.BorderSize = 0;
            this.cButton6.CausesValidation = false;
            this.cButton6.FlatAppearance.BorderSize = 0;
            this.cButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton6.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton6.ForeColor = System.Drawing.Color.Black;
            this.cButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton6.Location = new System.Drawing.Point(3, 14);
            this.cButton6.Name = "cButton6";
            this.cButton6.Size = new System.Drawing.Size(180, 41);
            this.cButton6.TabIndex = 0;
            this.cButton6.TabStop = false;
            this.cButton6.Text = "Thanh toán";
            this.cButton6.TextColor = System.Drawing.Color.Black;
            this.cButton6.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.cButton5);
            this.panel5.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel5.Location = new System.Drawing.Point(4, 414);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(186, 58);
            this.panel5.TabIndex = 7;
            // 
            // cButton5
            // 
            this.cButton5.BackColor = System.Drawing.Color.White;
            this.cButton5.BackgroundColor = System.Drawing.Color.White;
            this.cButton5.BorderColor = System.Drawing.Color.Transparent;
            this.cButton5.BorderRadius = 0;
            this.cButton5.BorderSize = 0;
            this.cButton5.CausesValidation = false;
            this.cButton5.FlatAppearance.BorderSize = 0;
            this.cButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton5.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton5.ForeColor = System.Drawing.Color.Black;
            this.cButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton5.Location = new System.Drawing.Point(3, 14);
            this.cButton5.Name = "cButton5";
            this.cButton5.Size = new System.Drawing.Size(180, 41);
            this.cButton5.TabIndex = 0;
            this.cButton5.TabStop = false;
            this.cButton5.Text = "Nhân viên";
            this.cButton5.TextColor = System.Drawing.Color.Black;
            this.cButton5.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.cButton4);
            this.panel4.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel4.Location = new System.Drawing.Point(4, 353);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(186, 58);
            this.panel4.TabIndex = 6;
            // 
            // cButton4
            // 
            this.cButton4.BackColor = System.Drawing.Color.Transparent;
            this.cButton4.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton4.BorderColor = System.Drawing.Color.Transparent;
            this.cButton4.BorderRadius = 0;
            this.cButton4.BorderSize = 0;
            this.cButton4.CausesValidation = false;
            this.cButton4.FlatAppearance.BorderSize = 0;
            this.cButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton4.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton4.ForeColor = System.Drawing.Color.Black;
            this.cButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton4.Location = new System.Drawing.Point(3, 14);
            this.cButton4.Name = "cButton4";
            this.cButton4.Size = new System.Drawing.Size(180, 41);
            this.cButton4.TabIndex = 0;
            this.cButton4.TabStop = false;
            this.cButton4.Text = "  Khách hàng";
            this.cButton4.TextColor = System.Drawing.Color.Black;
            this.cButton4.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.cButton3);
            this.panel3.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel3.Location = new System.Drawing.Point(4, 292);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(186, 58);
            this.panel3.TabIndex = 5;
            // 
            // cButton3
            // 
            this.cButton3.BackColor = System.Drawing.Color.Transparent;
            this.cButton3.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton3.BorderColor = System.Drawing.Color.Transparent;
            this.cButton3.BorderRadius = 0;
            this.cButton3.BorderSize = 0;
            this.cButton3.CausesValidation = false;
            this.cButton3.FlatAppearance.BorderSize = 0;
            this.cButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton3.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton3.ForeColor = System.Drawing.Color.Black;
            this.cButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton3.Location = new System.Drawing.Point(3, 14);
            this.cButton3.Name = "cButton3";
            this.cButton3.Size = new System.Drawing.Size(183, 41);
            this.cButton3.TabIndex = 0;
            this.cButton3.TabStop = false;
            this.cButton3.Text = "Sản phẩm";
            this.cButton3.TextColor = System.Drawing.Color.Black;
            this.cButton3.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.cButton2);
            this.panel2.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel2.Location = new System.Drawing.Point(4, 231);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 58);
            this.panel2.TabIndex = 4;
            // 
            // cButton2
            // 
            this.cButton2.BackColor = System.Drawing.Color.Transparent;
            this.cButton2.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton2.BorderColor = System.Drawing.Color.Transparent;
            this.cButton2.BorderRadius = 0;
            this.cButton2.BorderSize = 0;
            this.cButton2.CausesValidation = false;
            this.cButton2.FlatAppearance.BorderSize = 0;
            this.cButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton2.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton2.ForeColor = System.Drawing.Color.Black;
            this.cButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton2.Location = new System.Drawing.Point(3, 14);
            this.cButton2.Name = "cButton2";
            this.cButton2.Size = new System.Drawing.Size(183, 41);
            this.cButton2.TabIndex = 0;
            this.cButton2.TabStop = false;
            this.cButton2.Text = "Tài khoản";
            this.cButton2.TextColor = System.Drawing.Color.Black;
            this.cButton2.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.cButton1);
            this.panel1.Font = new System.Drawing.Font("Tahoma", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel1.Location = new System.Drawing.Point(4, 170);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(186, 58);
            this.panel1.TabIndex = 3;
            // 
            // cButton1
            // 
            this.cButton1.BackColor = System.Drawing.Color.Transparent;
            this.cButton1.BackgroundColor = System.Drawing.Color.Transparent;
            this.cButton1.BorderColor = System.Drawing.Color.Transparent;
            this.cButton1.BorderRadius = 0;
            this.cButton1.BorderSize = 0;
            this.cButton1.CausesValidation = false;
            this.cButton1.FlatAppearance.BorderSize = 0;
            this.cButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cButton1.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cButton1.ForeColor = System.Drawing.Color.Black;
            this.cButton1.Image = global::FaruSneaker.Properties.Resources.homeicons;
            this.cButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cButton1.Location = new System.Drawing.Point(3, 14);
            this.cButton1.Name = "cButton1";
            this.cButton1.Size = new System.Drawing.Size(183, 41);
            this.cButton1.TabIndex = 0;
            this.cButton1.TabStop = false;
            this.cButton1.Text = "Trang chủ";
            this.cButton1.TextColor = System.Drawing.Color.Black;
            this.cButton1.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::FaruSneaker.Properties.Resources.logo;
            this.pictureBox2.Location = new System.Drawing.Point(4, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(189, 164);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.txt_ci);
            this.groupBox1.Controls.Add(this.txt_add);
            this.groupBox1.Controls.Add(this.txt_ephone);
            this.groupBox1.Controls.Add(this.txt_ename);
            this.groupBox1.Controls.Add(this.txt_eid);
            this.groupBox1.Controls.Add(this.txt_salary);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.table_E);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.dob);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.btn_add);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(25, 81);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1133, 610);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "THÔNG TIN NHÂN VIÊN";
            // 
            // txt_ci
            // 
            this.txt_ci.Location = new System.Drawing.Point(309, 138);
            this.txt_ci.Name = "txt_ci";
            this.txt_ci.Size = new System.Drawing.Size(234, 32);
            this.txt_ci.TabIndex = 6;
            // 
            // txt_add
            // 
            this.txt_add.Location = new System.Drawing.Point(872, 75);
            this.txt_add.Name = "txt_add";
            this.txt_add.Size = new System.Drawing.Size(234, 32);
            this.txt_add.TabIndex = 4;
            // 
            // txt_ephone
            // 
            this.txt_ephone.Location = new System.Drawing.Point(584, 75);
            this.txt_ephone.Name = "txt_ephone";
            this.txt_ephone.Size = new System.Drawing.Size(234, 32);
            this.txt_ephone.TabIndex = 3;
            // 
            // txt_ename
            // 
            this.txt_ename.Location = new System.Drawing.Point(309, 70);
            this.txt_ename.Name = "txt_ename";
            this.txt_ename.Size = new System.Drawing.Size(234, 32);
            this.txt_ename.TabIndex = 2;
            // 
            // txt_eid
            // 
            this.txt_eid.Location = new System.Drawing.Point(36, 69);
            this.txt_eid.Name = "txt_eid";
            this.txt_eid.Size = new System.Drawing.Size(234, 32);
            this.txt_eid.TabIndex = 1;
            // 
            // txt_salary
            // 
            this.txt_salary.Location = new System.Drawing.Point(584, 138);
            this.txt_salary.Name = "txt_salary";
            this.txt_salary.Size = new System.Drawing.Size(234, 32);
            this.txt_salary.TabIndex = 7;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(288, 555);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(181, 37);
            this.button4.TabIndex = 9;
            this.button4.Text = "Thanh toán lương";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(89, 555);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(181, 37);
            this.button5.TabIndex = 8;
            this.button5.Text = "Chấm công";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // table_E
            // 
            this.table_E.AllowUserToAddRows = false;
            this.table_E.AllowUserToDeleteRows = false;
            this.table_E.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.table_E.Location = new System.Drawing.Point(89, 211);
            this.table_E.MultiSelect = false;
            this.table_E.Name = "table_E";
            this.table_E.ReadOnly = true;
            this.table_E.RowHeadersWidth = 51;
            this.table_E.RowTemplate.Height = 29;
            this.table_E.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.table_E.Size = new System.Drawing.Size(967, 329);
            this.table_E.TabIndex = 54;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(584, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 24);
            this.label8.TabIndex = 50;
            this.label8.Text = "Mức lương";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(309, 111);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 24);
            this.label7.TabIndex = 48;
            this.label7.Text = "CCCD";
            // 
            // dob
            // 
            this.dob.Location = new System.Drawing.Point(36, 138);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(234, 32);
            this.dob.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(36, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 24);
            this.label6.TabIndex = 45;
            this.label6.Text = "Ngày sinh";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(690, 555);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(181, 37);
            this.button3.TabIndex = 11;
            this.button3.Text = "Xóa ";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(899, 555);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 37);
            this.button1.TabIndex = 12;
            this.button1.Text = "Cập nhật";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(872, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 24);
            this.label5.TabIndex = 41;
            this.label5.Text = "Địa chỉ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(309, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 24);
            this.label3.TabIndex = 39;
            this.label3.Text = "Họ tên nhân viên";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label11.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(485, 184);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(154, 24);
            this.label11.TabIndex = 30;
            this.label11.Text = "DANH SÁCH NHÂN VIÊN";
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(197)))), ((int)(((byte)(57)))));
            this.btn_add.ForeColor = System.Drawing.Color.Black;
            this.btn_add.Location = new System.Drawing.Point(486, 555);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(181, 37);
            this.btn_add.TabIndex = 10;
            this.btn_add.Text = "Thêm";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(36, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 24);
            this.label2.TabIndex = 9;
            this.label2.Text = "Mã nhân viên";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(584, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 24);
            this.label4.TabIndex = 13;
            this.label4.Text = "Số điện thoại";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btn_search);
            this.panel8.Controls.Add(this.txt_search);
            this.panel8.Controls.Add(this.label1);
            this.panel8.Controls.Add(this.pictureBox1);
            this.panel8.Location = new System.Drawing.Point(4, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1175, 78);
            this.panel8.TabIndex = 1;
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.btn_search.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.btn_search.BorderColor = System.Drawing.Color.Transparent;
            this.btn_search.BorderRadius = 1;
            this.btn_search.BorderSize = 0;
            this.btn_search.FlatAppearance.BorderSize = 0;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.ForeColor = System.Drawing.Color.Transparent;
            this.btn_search.Image = global::FaruSneaker.Properties.Resources.search;
            this.btn_search.Location = new System.Drawing.Point(567, 20);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(81, 39);
            this.btn_search.TabIndex = 14;
            this.btn_search.TextColor = System.Drawing.Color.Transparent;
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click_1);
            // 
            // txt_search
            // 
            this.txt_search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(232)))), ((int)(((byte)(232)))));
            this.txt_search.Font = new System.Drawing.Font("Bahnschrift Condensed", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_search.Location = new System.Drawing.Point(57, 20);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(591, 40);
            this.txt_search.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1053, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Đăng xuất";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(-3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1178, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // error
            // 
            this.error.ContainerControl = this;
            // 
            // employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1376, 703);
            this.Controls.Add(this.splitContainer1);
            this.Name = "employee";
            this.Text = "employee";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.table_E)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.error)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private SplitContainer splitContainer1;
        private Panel panel6;
        private CButton cButton6;
        private Panel panel5;
        private CButton cButton5;
        private Panel panel4;
        private CButton cButton4;
        private Panel panel3;
        private CButton cButton3;
        private Panel panel2;
        private CButton cButton2;
        private Panel panel1;
        private CButton cButton1;
        private PictureBox pictureBox2;
        private Panel panel8;
        private Label label1;
        private CButton btn_search;
        private PictureBox pictureBox1;
        private ErrorProvider error;
        private TextBox txt_search;
        private GroupBox groupBox1;
        private TextBox txt_ci;
        private TextBox txt_add;
        private TextBox txt_ephone;
        private TextBox txt_ename;
        private TextBox txt_eid;
        private TextBox txt_salary;
        private Button button4;
        private Button button5;
        private DataGridView table_E;
        private Label label8;
        private Label label7;
        private DateTimePicker dob;
        private Label label6;
        private Button button3;
        private Button button1;
        private Label label5;
        private Label label3;
        private Label label11;
        private Button btn_add;
        private Label label2;
        private Label label4;
    }
}