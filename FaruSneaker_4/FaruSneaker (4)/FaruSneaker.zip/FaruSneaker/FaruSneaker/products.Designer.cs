﻿namespace FaruSneaker
{
    partial class products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel8 = new Panel();
            btn_search = new CButton();
            txt_search = new TextBox();
            panel1 = new Panel();
            cButton1 = new CButton();
            panel2 = new Panel();
            cButton2 = new CButton();
            panel3 = new Panel();
            cButton3 = new CButton();
            panel4 = new Panel();
            cButton4 = new CButton();
            panel5 = new Panel();
            cButton5 = new CButton();
            pictureBox2 = new PictureBox();
            panel6 = new Panel();
            cButton6 = new CButton();
            splitContainer1 = new SplitContainer();
            groupBox1 = new GroupBox();
            txt_importprice = new TextBox();
            txt_price = new TextBox();
            txt_brand = new TextBox();
            txt_name = new TextBox();
            txt_id = new TextBox();
            dgv_product = new DataGridView();
            btn_update = new Button();
            btn_delete = new Button();
            label11 = new Label();
            btn_add = new Button();
            btn_Clear = new Button();
            ptb_Image = new PictureBox();
            label10 = new Label();
            dtm_productImportDate = new DateTimePicker();
            label9 = new Label();
            label8 = new Label();
            nbr_productNum = new NumericUpDown();
            label7 = new Label();
            nbr_productSize = new NumericUpDown();
            label6 = new Label();
            cbx_productColor = new ComboBox();
            label5 = new Label();
            label2 = new Label();
            label4 = new Label();
            label3 = new Label();
            openFileDialog1 = new OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel8.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_product).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptb_Image).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nbr_productNum).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nbr_productSize).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(48, 48, 48);
            label1.Font = new Font("Bahnschrift", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(1053, 25);
            label1.Name = "label1";
            label1.Size = new Size(101, 24);
            label1.TabIndex = 1;
            label1.Text = "Đăng xuất";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(48, 48, 48);
            pictureBox1.BorderStyle = BorderStyle.Fixed3D;
            pictureBox1.Location = new Point(-3, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1178, 75);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel8
            // 
            panel8.Controls.Add(btn_search);
            panel8.Controls.Add(label1);
            panel8.Controls.Add(txt_search);
            panel8.Controls.Add(pictureBox1);
            panel8.Location = new Point(5, 2);
            panel8.Name = "panel8";
            panel8.Size = new Size(1175, 78);
            panel8.TabIndex = 0;
            // 
            // btn_search
            // 
            btn_search.BackColor = Color.FromArgb(232, 232, 232);
            btn_search.BackgroundColor = Color.FromArgb(232, 232, 232);
            btn_search.BorderColor = Color.Transparent;
            btn_search.BorderRadius = 1;
            btn_search.BorderSize = 0;
            btn_search.FlatAppearance.BorderSize = 0;
            btn_search.FlatStyle = FlatStyle.Flat;
            btn_search.ForeColor = Color.Transparent;
            btn_search.Image = Properties.Resources.search;
            btn_search.Location = new Point(546, 15);
            btn_search.Name = "btn_search";
            btn_search.Size = new Size(81, 39);
            btn_search.TabIndex = 54;
            btn_search.TextColor = Color.Transparent;
            btn_search.UseVisualStyleBackColor = false;
            // 
            // txt_search
            // 
            txt_search.BackColor = Color.FromArgb(232, 232, 232);
            txt_search.Font = new Font("Bahnschrift Condensed", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            txt_search.Location = new Point(36, 15);
            txt_search.Name = "txt_search";
            txt_search.Size = new Size(591, 40);
            txt_search.TabIndex = 55;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(cButton1);
            panel1.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel1.Location = new Point(3, 171);
            panel1.Name = "panel1";
            panel1.Size = new Size(186, 58);
            panel1.TabIndex = 2;
            // 
            // cButton1
            // 
            cButton1.BackColor = Color.Transparent;
            cButton1.BackgroundColor = Color.Transparent;
            cButton1.BorderColor = Color.Transparent;
            cButton1.BorderRadius = 0;
            cButton1.BorderSize = 0;
            cButton1.CausesValidation = false;
            cButton1.FlatAppearance.BorderSize = 0;
            cButton1.FlatStyle = FlatStyle.Flat;
            cButton1.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Bold, GraphicsUnit.Point);
            cButton1.ForeColor = Color.Black;
            cButton1.Image = Properties.Resources.homeicons;
            cButton1.ImageAlign = ContentAlignment.MiddleLeft;
            cButton1.Location = new Point(2, 9);
            cButton1.Name = "cButton1";
            cButton1.Size = new Size(183, 41);
            cButton1.TabIndex = 1;
            cButton1.TabStop = false;
            cButton1.Text = "Trang chủ";
            cButton1.TextColor = Color.Black;
            cButton1.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Transparent;
            panel2.Controls.Add(cButton2);
            panel2.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel2.Location = new Point(3, 232);
            panel2.Name = "panel2";
            panel2.Size = new Size(186, 58);
            panel2.TabIndex = 3;
            // 
            // cButton2
            // 
            cButton2.BackColor = Color.Transparent;
            cButton2.BackgroundColor = Color.Transparent;
            cButton2.BorderColor = Color.Transparent;
            cButton2.BorderRadius = 0;
            cButton2.BorderSize = 0;
            cButton2.CausesValidation = false;
            cButton2.FlatAppearance.BorderSize = 0;
            cButton2.FlatStyle = FlatStyle.Flat;
            cButton2.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Bold, GraphicsUnit.Point);
            cButton2.ForeColor = Color.Black;
            cButton2.ImageAlign = ContentAlignment.MiddleLeft;
            cButton2.Location = new Point(2, 9);
            cButton2.Name = "cButton2";
            cButton2.Size = new Size(183, 41);
            cButton2.TabIndex = 1;
            cButton2.TabStop = false;
            cButton2.Text = "Tài khoản";
            cButton2.TextColor = Color.Black;
            cButton2.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.Controls.Add(cButton3);
            panel3.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel3.Location = new Point(3, 293);
            panel3.Name = "panel3";
            panel3.Size = new Size(186, 58);
            panel3.TabIndex = 4;
            // 
            // cButton3
            // 
            cButton3.BackColor = Color.FromArgb(235, 234, 236);
            cButton3.BackgroundColor = Color.FromArgb(235, 234, 236);
            cButton3.BorderColor = Color.Transparent;
            cButton3.BorderRadius = 0;
            cButton3.BorderSize = 0;
            cButton3.CausesValidation = false;
            cButton3.FlatAppearance.BorderSize = 0;
            cButton3.FlatStyle = FlatStyle.Flat;
            cButton3.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Bold, GraphicsUnit.Point);
            cButton3.ForeColor = Color.Black;
            cButton3.ImageAlign = ContentAlignment.MiddleLeft;
            cButton3.Location = new Point(2, 9);
            cButton3.Name = "cButton3";
            cButton3.Size = new Size(183, 41);
            cButton3.TabIndex = 1;
            cButton3.TabStop = false;
            cButton3.Text = "Sản phẩm";
            cButton3.TextColor = Color.Black;
            cButton3.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Transparent;
            panel4.Controls.Add(cButton4);
            panel4.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel4.Location = new Point(6, 354);
            panel4.Name = "panel4";
            panel4.Size = new Size(186, 58);
            panel4.TabIndex = 5;
            // 
            // cButton4
            // 
            cButton4.BackColor = Color.Transparent;
            cButton4.BackgroundColor = Color.Transparent;
            cButton4.BorderColor = Color.Transparent;
            cButton4.BorderRadius = 0;
            cButton4.BorderSize = 0;
            cButton4.CausesValidation = false;
            cButton4.FlatAppearance.BorderSize = 0;
            cButton4.FlatStyle = FlatStyle.Flat;
            cButton4.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Bold, GraphicsUnit.Point);
            cButton4.ForeColor = Color.Black;
            cButton4.ImageAlign = ContentAlignment.MiddleLeft;
            cButton4.Location = new Point(3, 9);
            cButton4.Name = "cButton4";
            cButton4.Size = new Size(180, 41);
            cButton4.TabIndex = 1;
            cButton4.TabStop = false;
            cButton4.Text = "  Khách hàng";
            cButton4.TextColor = Color.Black;
            cButton4.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.Controls.Add(cButton5);
            panel5.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel5.Location = new Point(6, 415);
            panel5.Name = "panel5";
            panel5.Size = new Size(186, 58);
            panel5.TabIndex = 6;
            // 
            // cButton5
            // 
            cButton5.BackColor = Color.Transparent;
            cButton5.BackgroundColor = Color.Transparent;
            cButton5.BorderColor = Color.Transparent;
            cButton5.BorderRadius = 0;
            cButton5.BorderSize = 0;
            cButton5.CausesValidation = false;
            cButton5.FlatAppearance.BorderSize = 0;
            cButton5.FlatStyle = FlatStyle.Flat;
            cButton5.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Bold, GraphicsUnit.Point);
            cButton5.ForeColor = Color.Black;
            cButton5.ImageAlign = ContentAlignment.MiddleLeft;
            cButton5.Location = new Point(3, 9);
            cButton5.Name = "cButton5";
            cButton5.Size = new Size(180, 41);
            cButton5.TabIndex = 1;
            cButton5.TabStop = false;
            cButton5.Text = "Nhân viên";
            cButton5.TextColor = Color.Black;
            cButton5.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.Transparent;
            pictureBox2.Image = Properties.Resources.logo;
            pictureBox2.Location = new Point(3, 5);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(189, 164);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 8;
            pictureBox2.TabStop = false;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Transparent;
            panel6.Controls.Add(cButton6);
            panel6.Font = new Font("Tahoma", 7.2F, FontStyle.Regular, GraphicsUnit.Point);
            panel6.Location = new Point(6, 476);
            panel6.Name = "panel6";
            panel6.Size = new Size(186, 58);
            panel6.TabIndex = 7;
            // 
            // cButton6
            // 
            cButton6.BackColor = Color.Transparent;
            cButton6.BackgroundColor = Color.Transparent;
            cButton6.BorderColor = Color.Transparent;
            cButton6.BorderRadius = 0;
            cButton6.BorderSize = 0;
            cButton6.CausesValidation = false;
            cButton6.FlatAppearance.BorderSize = 0;
            cButton6.FlatStyle = FlatStyle.Flat;
            cButton6.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Bold, GraphicsUnit.Point);
            cButton6.ForeColor = Color.Black;
            cButton6.ImageAlign = ContentAlignment.MiddleLeft;
            cButton6.Location = new Point(3, 9);
            cButton6.Name = "cButton6";
            cButton6.Size = new Size(180, 41);
            cButton6.TabIndex = 1;
            cButton6.TabStop = false;
            cButton6.Text = "Thanh toán";
            cButton6.TextColor = Color.Black;
            cButton6.UseVisualStyleBackColor = false;
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.FromArgb(223, 194, 57);
            splitContainer1.Panel1.BackgroundImageLayout = ImageLayout.Stretch;
            splitContainer1.Panel1.Controls.Add(pictureBox2);
            splitContainer1.Panel1.Controls.Add(panel6);
            splitContainer1.Panel1.Controls.Add(panel5);
            splitContainer1.Panel1.Controls.Add(panel4);
            splitContainer1.Panel1.Controls.Add(panel3);
            splitContainer1.Panel1.Controls.Add(panel2);
            splitContainer1.Panel1.Controls.Add(panel1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(panel8);
            splitContainer1.Panel2.Controls.Add(groupBox1);
            splitContainer1.Size = new Size(1376, 703);
            splitContainer1.SplitterDistance = 192;
            splitContainer1.TabIndex = 1;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(txt_importprice);
            groupBox1.Controls.Add(txt_price);
            groupBox1.Controls.Add(txt_brand);
            groupBox1.Controls.Add(txt_name);
            groupBox1.Controls.Add(txt_id);
            groupBox1.Controls.Add(dgv_product);
            groupBox1.Controls.Add(btn_update);
            groupBox1.Controls.Add(btn_delete);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(btn_add);
            groupBox1.Controls.Add(btn_Clear);
            groupBox1.Controls.Add(ptb_Image);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(dtm_productImportDate);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(nbr_productNum);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(nbr_productSize);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(cbx_productColor);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(26, 86);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1133, 575);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "THÔNG TIN SẢN PHẨM";
            // 
            // txt_importprice
            // 
            txt_importprice.Location = new Point(15, 218);
            txt_importprice.Name = "txt_importprice";
            txt_importprice.Size = new Size(234, 32);
            txt_importprice.TabIndex = 38;
            // 
            // txt_price
            // 
            txt_price.Location = new Point(286, 146);
            txt_price.Name = "txt_price";
            txt_price.Size = new Size(234, 32);
            txt_price.TabIndex = 37;
            // 
            // txt_brand
            // 
            txt_brand.Location = new Point(15, 146);
            txt_brand.Name = "txt_brand";
            txt_brand.Size = new Size(234, 32);
            txt_brand.TabIndex = 36;
            // 
            // txt_name
            // 
            txt_name.Location = new Point(286, 69);
            txt_name.Name = "txt_name";
            txt_name.Size = new Size(234, 32);
            txt_name.TabIndex = 35;
            // 
            // txt_id
            // 
            txt_id.Location = new Point(15, 68);
            txt_id.Name = "txt_id";
            txt_id.Size = new Size(234, 32);
            txt_id.TabIndex = 34;
            // 
            // dgv_product
            // 
            dgv_product.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_product.Location = new Point(546, 69);
            dgv_product.Name = "dgv_product";
            dgv_product.RowHeadersWidth = 51;
            dgv_product.RowTemplate.Height = 29;
            dgv_product.Size = new Size(564, 458);
            dgv_product.TabIndex = 33;
            // 
            // btn_update
            // 
            btn_update.BackColor = Color.FromArgb(233, 197, 57);
            btn_update.ForeColor = Color.Black;
            btn_update.Location = new Point(387, 490);
            btn_update.Name = "btn_update";
            btn_update.Size = new Size(133, 37);
            btn_update.TabIndex = 32;
            btn_update.Text = "Cập nhật ";
            btn_update.UseVisualStyleBackColor = false;
            // 
            // btn_delete
            // 
            btn_delete.BackColor = Color.FromArgb(233, 197, 57);
            btn_delete.ForeColor = Color.Black;
            btn_delete.Location = new Point(202, 490);
            btn_delete.Name = "btn_delete";
            btn_delete.Size = new Size(133, 37);
            btn_delete.TabIndex = 31;
            btn_delete.Text = "Xóa ";
            btn_delete.UseVisualStyleBackColor = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(756, 42);
            label11.Name = "label11";
            label11.Size = new Size(140, 24);
            label11.TabIndex = 30;
            label11.Text = "THEO DÕI SẢN PHẨM";
            // 
            // btn_add
            // 
            btn_add.BackColor = Color.FromArgb(233, 197, 57);
            btn_add.ForeColor = Color.Black;
            btn_add.Location = new Point(15, 490);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(133, 37);
            btn_add.TabIndex = 28;
            btn_add.Text = "Thêm";
            btn_add.UseVisualStyleBackColor = false;
            // 
            // btn_Clear
            // 
            btn_Clear.BackColor = Color.FromArgb(224, 224, 224);
            btn_Clear.ForeColor = Color.Black;
            btn_Clear.Location = new Point(387, 427);
            btn_Clear.Name = "btn_Clear";
            btn_Clear.Size = new Size(133, 32);
            btn_Clear.TabIndex = 27;
            btn_Clear.Text = "Xóa tùy chọn";
            btn_Clear.UseVisualStyleBackColor = false;
            // 
            // ptb_Image
            // 
            ptb_Image.BackColor = Color.Transparent;
            ptb_Image.BorderStyle = BorderStyle.Fixed3D;
            ptb_Image.Image = Properties.Resources.logo1;
            ptb_Image.Location = new Point(286, 198);
            ptb_Image.Name = "ptb_Image";
            ptb_Image.Size = new Size(234, 206);
            ptb_Image.SizeMode = PictureBoxSizeMode.StretchImage;
            ptb_Image.TabIndex = 26;
            ptb_Image.TabStop = false;
            ptb_Image.Click += ptb_Image_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(15, 431);
            label10.Name = "label10";
            label10.Size = new Size(115, 24);
            label10.TabIndex = 25;
            label10.Text = "Ngày nhập hàng";
            // 
            // dtm_productImportDate
            // 
            dtm_productImportDate.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dtm_productImportDate.Location = new Point(136, 425);
            dtm_productImportDate.Name = "dtm_productImportDate";
            dtm_productImportDate.Size = new Size(233, 32);
            dtm_productImportDate.TabIndex = 24;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(15, 191);
            label9.Name = "label9";
            label9.Size = new Size(103, 24);
            label9.TabIndex = 23;
            label9.Text = "Giá nhập hàng";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(286, 119);
            label8.Name = "label8";
            label8.Size = new Size(59, 24);
            label8.TabIndex = 21;
            label8.Text = "Đơn giá";
            // 
            // nbr_productNum
            // 
            nbr_productNum.Location = new Point(136, 322);
            nbr_productNum.Name = "nbr_productNum";
            nbr_productNum.Size = new Size(79, 32);
            nbr_productNum.TabIndex = 19;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(15, 380);
            label7.Name = "label7";
            label7.Size = new Size(81, 24);
            label7.TabIndex = 18;
            label7.Text = "Kích thước";
            // 
            // nbr_productSize
            // 
            nbr_productSize.Location = new Point(136, 372);
            nbr_productSize.Name = "nbr_productSize";
            nbr_productSize.Size = new Size(79, 32);
            nbr_productSize.TabIndex = 17;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(15, 330);
            label6.Name = "label6";
            label6.Size = new Size(69, 24);
            label6.TabIndex = 16;
            label6.Text = "Số lượng";
            // 
            // cbx_productColor
            // 
            cbx_productColor.DropDownStyle = ComboBoxStyle.DropDownList;
            cbx_productColor.FormattingEnabled = true;
            cbx_productColor.Items.AddRange(new object[] { "Đỏ", "Xanh", "Trắng", "Vàng", "Hồng", "Cam", "Tím", "Xanh lá", "Thêm màu" });
            cbx_productColor.Location = new Point(85, 274);
            cbx_productColor.Name = "cbx_productColor";
            cbx_productColor.Size = new Size(164, 32);
            cbx_productColor.TabIndex = 15;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(15, 282);
            label5.Name = "label5";
            label5.Size = new Size(64, 24);
            label5.TabIndex = 14;
            label5.Text = "Màu sắc";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(15, 41);
            label2.Name = "label2";
            label2.Size = new Size(95, 24);
            label2.TabIndex = 9;
            label2.Text = "Mã mặt hàng";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(15, 119);
            label4.Name = "label4";
            label4.Size = new Size(90, 24);
            label4.TabIndex = 13;
            label4.Text = "Thương hiệu";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bahnschrift Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(286, 41);
            label3.Name = "label3";
            label3.Size = new Size(98, 24);
            label3.TabIndex = 11;
            label3.Text = "Tên mặt hàng";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // products
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1376, 703);
            Controls.Add(splitContainer1);
            Name = "products";
            Text = "Sản phẩm";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel6.ResumeLayout(false);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_product).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptb_Image).EndInit();
            ((System.ComponentModel.ISupportInitialize)nbr_productNum).EndInit();
            ((System.ComponentModel.ISupportInitialize)nbr_productSize).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Panel panel8;
        /*private CustomControls.RJControls.RJTextBox rjTextBox1;*/
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private PictureBox pictureBox2;
        private Panel panel6;
        private SplitContainer splitContainer1;
        private GroupBox groupBox1;
        private ComboBox cbx_productColor;
        private Label label5;
        private Label label2;
        private Label label4;
        /*private CustomControls.RJControls.RJTextBox txt_productBrand;*/
        /*private CustomControls.RJControls.RJTextBox txt_productName;
        private CustomControls.RJControls.RJTextBox txt_productPrice;*/
        private Label label3;
        private Label label10;
        private DateTimePicker dtm_productImportDate;
        private Label label9;
        /*private CustomControls.RJControls.RJTextBox txt_productImportPrice;*/
        private Label label8;
        /*private CustomControls.RJControls.RJTextBox txt_productID;*/
        private NumericUpDown nbr_productNum;
        private Label label7;
        private NumericUpDown nbr_productSize;
        private Label label6;
        private Button btn_Clear;
        private PictureBox ptb_Image;
        private Button btn_add;
        private Button btn_update;
        private Button btn_delete;
        private Label label11;
        private DataGridView dgv_product;
        /*private CButton cButton1;
        private CButton cButton2;
        private CButton cButton6;
        private CButton cButton3;
        private CButton cButton5;
        private CButton cButton4;
        private CButton cButton7;
        private CButton cButton8;
        private CButton cButton12;
        private CButton cButton9;
        private CButton cButton11;
        private CButton cButton10;
        private CButton cButton13;
        *//*private CButton item_KH;*//*
        private CButton cButton14;
        private CButton cButton15;
        private CButton cButton16;*/
        private TextBox txt_importprice;
        private TextBox txt_price;
        private TextBox txt_brand;
        private TextBox txt_name;
        private TextBox txt_id;
        private CButton cButton1;
        private CButton cButton2;
        private CButton cButton3;
        private CButton cButton4;
        private CButton cButton5;
        private CButton cButton6;
        private CButton btn_search;
        private TextBox txt_search;
        private OpenFileDialog openFileDialog1;
    }
}